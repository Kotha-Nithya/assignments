
var firstNumber,secondNumber,result;

function getValues(){
   firstNumber = Number(document.getElementById('firstNumber').value)
   secondNumber = Number(document.getElementById('secondNumber').value)
}
function addition(){    
    getValues()
    result = firstNumber + secondNumber
    document.getElementById('result').value = result
}
function subtraction(){
    getValues()
    result = firstNumber-secondNumber
    document.getElementById('result').value = result
}
function multiplication(){    
    getValues()
    result = firstNumber * secondNumber
    document.getElementById('result').value = result
}
function division(){    
    getValues()
    result = firstNumber / secondNumber
    document.getElementById('result').value = result
}
