var bank = {
    custId:100,
    custName:'nithya',
    custAcno:546789090,
    getSavingDeposit(){
        console.log(this.custName+'your account no-->'+this.custAcno+'has a savings of 50%')
    },
    getReccuringDeposit(){
        console.log(this.custName+'your account no-->'+this.custAcno+'has a reccuring deposit of 30%')
    },
    getFixedDeposit(){
        console.log(this.custName+'your account no-->'+this.custAcno+'has a fixed deposit of 20%')
    },   
}
console.log(bank)
console.log(bank.custName)
console.log(bank.custAcno)
console.log(bank.getReccuringDeposit())
console.log(bank.getSavingDeposit())
console.log(bank.getFixedDeposit())