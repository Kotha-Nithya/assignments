function bank(custId,custName,custAcNumber){
    this.custId = custId;
    this.custName =custName;
    this.custAcNumber=custAcNumber;
}
var hdfcBank = new bank(100,'nithya',890765);
var sbiBank = new bank(101,'sathya',890790);
var unionBank = new bank(102,'nithya',876765);
console.log(hdfcBank.custId,hdfcBank.custName,hdfcBank.custAcNumber)
console.log(sbiBank.custId,sbiBank.custName,sbiBank.custAcNumber)   
console.log(unionBank.custId,unionBank.custName,unionBank.custAcNumber)      