function getModifyData(){
    var myAge = document.getElementById('myage').value
    var marriage = (myAge<20)?'You are not eligible':"Your are eligable"
    // console.log(marriage)
    document.getElementById('myAgeResult').innerHTML = marriage
}
