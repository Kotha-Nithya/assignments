function weekdayprogram(){
    var day=Number(document.getElementById('week').value)
    console.log(day);
switch(day){
    case 1: document.write('monday');
    break;
    case 2: document.write('tuesday');
    break;
    case 3: document.write('wednesday');
    break;
    case 4: document.write('thursday');
    break;
    case 5: document.write('friday');
    break;
    case 6: document.write('saturday');
    break;
    default: document.write('sunday');
    break;
}
}