var Employee = /** @class */ (function () {
    function Employee(name, age) {
        this.empName = name;
        this.empAge = age;
    }
    Employee.prototype.getEmployeeInfo = function () {
        return "EmployeeName:" + this.empName + " and EmployeeAge:" + this.empAge;
    };
    return Employee;
}());
var sureshEmp = new Employee('suresh', 22);
var swethaEmp = new Employee('swetha', 22);
console.log(sureshEmp.empName, sureshEmp.empAge);
console.log(swethaEmp.empName, swethaEmp.empAge);
console.log(sureshEmp.getEmployeeInfo());
console.log(swethaEmp.getEmployeeInfo());
