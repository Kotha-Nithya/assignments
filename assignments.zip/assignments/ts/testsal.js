function testconst() {
    var sal = 300000;
    sal = 400000;
    console.log(sal);
}
testconst();
