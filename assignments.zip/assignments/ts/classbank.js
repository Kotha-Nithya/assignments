var Bank = /** @class */ (function () {
    function Bank(id, name, accno) {
        this.custId = id;
        this.custName = name;
        this.custAcNo = accno;
    }
    Bank.prototype.getSavingDeposit = function () {
        return "customerName:" + this.custName + " and his savings are 70%";
    };
    Bank.prototype.getReccuringDeposit = function () {
        return "customerName:" + this.custName + " and his reccuringdeposit is 5%";
    };
    Bank.prototype.getFixedDeposit = function () {
        return "customerName:" + this.custName + " and his fixeddeposit is 60%";
    };
    return Bank;
}());
var cust1 = new Bank(100, 'sathya', 890765);
var cust2 = new Bank(101, 'srija', 9087655);
var cust3 = new Bank(102, 'nithya', 9085455);
console.log(cust1.custId, cust1.custName, cust1.custAcNo);
console.log(cust2.custId, cust2.custName, cust2.custAcNo);
console.log(cust3.custId, cust3.custName, cust3.custAcNo);
console.log(cust1.getReccuringDeposit());
console.log(cust2.getSavingDeposit());
console.log(cust3.getFixedDeposit());
