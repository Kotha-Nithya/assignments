class Employee{
    empName:string;
    empAge:number;
    constructor(name:string,age:number){
        this.empName = name;
        this.empAge = age;
    }
    getEmployeeInfo(){
        return `EmployeeName:${this.empName} and EmployeeAge:${this.empAge}`
    }
}
let sureshEmp =new Employee('suresh',22)
let swethaEmp=new Employee('swetha',22)

console.log(sureshEmp.empName,sureshEmp.empAge)
console.log(swethaEmp.empName,swethaEmp.empAge)
console.log(sureshEmp.getEmployeeInfo())
console.log(swethaEmp.getEmployeeInfo())


